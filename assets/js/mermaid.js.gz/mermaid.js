$(document).ready(function() {
  mermaid.initialize({
      theme: 'forest'
  });
});